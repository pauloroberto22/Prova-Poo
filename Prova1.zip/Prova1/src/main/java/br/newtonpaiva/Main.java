package br.newtonpaiva
import java.util.LinkedList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

       var f= new Fornecedor(11,"Paulo","5245454154","9945822");

       var p= new Produto(22,"beterraba","Novo","22","24","2","Vilma");


    }
}